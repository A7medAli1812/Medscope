import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import FeaturesSection from "@/components/features-section"
import HospitalsSection from "@/components/hospitals-section"
import ServicesSection from "@/components/services-section"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <FeaturesSection />
      <HospitalsSection />
      <ServicesSection />
      <Footer />
    </main>
  )
}
