import { Button } from "@/components/ui/button"
import { User, UserPlus } from "lucide-react"
import Image from "next/image"

export default function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <Image src="/images/logo.jpg" alt="MedScope Logo" width={45} height={45} className="rounded-full" />
          <div>
            <h1 className="text-[#1e3a5f] font-bold text-lg leading-tight">MedScope</h1>
            <p className="text-[#0891B2] text-xs">Healthcare Excellence</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <a href="#" className="text-gray-700 hover:text-[#0891B2] font-medium">
            Home
          </a>
          <a href="#" className="text-gray-700 hover:text-[#0891B2] font-medium">
            Hospitals
          </a>
          <a
            href="#"
            className="text-gray-700 hover:text-[#0891B2] font-medium underline decoration-[#0891B2] underline-offset-4"
          >
            Services
          </a>
          <a href="#" className="text-gray-700 hover:text-[#0891B2] font-medium">
            About
          </a>
        </nav>

        {/* Auth Buttons */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            className="border-[#0891B2] text-[#0891B2] hover:bg-[#0891B2] hover:text-white bg-transparent"
          >
            <User className="w-4 h-4 mr-2" />
            Sign In
          </Button>
          <Button className="bg-[#0891B2] hover:bg-[#0e7490] text-white">
            <UserPlus className="w-4 h-4 mr-2" />
            Sign UP
          </Button>
        </div>
      </div>
    </header>
  )
}
