import { Calendar, Bed, Droplets, ClipboardList, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const services = [
  {
    icon: Bed,
    title: "Available Beds (ICU & Incubators)",
    features: ["Live Updates", "Location Based"],
    badge: "Real time",
    badgeColor: "bg-red-500",
    buttonText: "Login to View",
  },
  {
    icon: Droplets,
    title: "Blood Bank",
    features: ["Multiple Locations"],
    badge: "Essential",
    badgeColor: "bg-[#0891B2]",
    buttonText: "Login to Blood Bank",
  },
  {
    icon: ClipboardList,
    title: "My Appointments",
    features: ["History", "Reschedule"],
    badge: "Personal",
    badgeColor: "bg-[#0891B2]",
    buttonText: "Login to View Appointments",
  },
]

export default function ServicesSection() {
  return (
    <section className="py-16 bg-[#E0F2FE]">
      <div className="container mx-auto px-4 text-center">
        {/* Badge */}
        <span className="inline-block bg-[#164E63] text-white text-sm px-4 py-1 rounded-full mb-4">
          Platform Services
        </span>

        <h2 className="text-[#164E63] text-3xl md:text-4xl font-bold mb-4">
          Comprehensive Healthcare
          <br />
          Management Tools
        </h2>

        <p className="text-gray-600 max-w-xl mx-auto mb-12">
          Access powerful healthcare management tools designed to streamline your medical journey
        </p>

        {/* Main Appointment Card */}
        <div className="relative rounded-3xl overflow-hidden shadow-xl mb-8 max-w-3xl mx-auto">
          <img src="/doctor-with-digital-technology-ai-hologram-medical.jpg" alt="Doctor Appointments" className="w-full h-80 object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#164E63]/90 to-transparent" />

          {/* Badge */}
          <div className="absolute top-4 right-4 bg-[#0891B2] text-white text-xs px-3 py-1 rounded-full">
            Most Popular
          </div>

          {/* Icon */}
          <div className="absolute top-4 left-4 w-10 h-10 bg-[#0891B2] rounded-lg flex items-center justify-center">
            <Calendar className="w-5 h-5 text-white" />
          </div>

          {/* Content */}
          <div className="absolute bottom-6 left-6 text-left">
            <h3 className="text-white font-bold text-2xl mb-2">Doctor Appointments Booking</h3>
            <div className="flex gap-4 mb-4">
              <span className="flex items-center text-white/80 text-sm">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                Instant Booking
              </span>
              <span className="flex items-center text-white/80 text-sm">
                <span className="w-2 h-2 bg-yellow-400 rounded-full mr-2"></span>
                Reminders
              </span>
            </div>
            <Button variant="link" className="text-[#0891B2] p-0 hover:text-[#06b6d4]">
              Login to Book <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl p-6 shadow-lg text-left">
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-[#164E63] rounded-xl flex items-center justify-center">
                  <service.icon className="w-6 h-6 text-white" />
                </div>
                <span className={`${service.badgeColor} text-white text-xs px-2 py-1 rounded-full`}>
                  {service.badge}
                </span>
              </div>

              <h3 className="text-[#164E63] font-bold text-lg mb-3">{service.title}</h3>

              <div className="flex gap-4 mb-4">
                {service.features.map((feature, i) => (
                  <span key={i} className="flex items-center text-gray-500 text-sm">
                    <span className="w-1.5 h-1.5 bg-[#0891B2] rounded-full mr-2"></span>
                    {feature}
                  </span>
                ))}
              </div>

              <Button className="w-full bg-[#164E63] hover:bg-[#0e4155] text-white rounded-xl">
                {service.buttonText} <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
