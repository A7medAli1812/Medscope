import { Mail, Phone, AlertTriangle, Facebook, Instagram, Twitter, Linkedin } from "lucide-react"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="bg-[#164E63] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Logo & Description */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Image src="/images/logo.jpg" alt="MedScope Logo" width={45} height={45} className="rounded-full" />
              <div>
                <h3 className="text-white font-bold text-lg">MedScope</h3>
                <p className="text-[#0891B2] text-xs">Healthcare Excellence</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed mb-4">
              Advanced hospital management platform connecting patients with quality healthcare services. Your health is
              our priority, and we're committed to providing exceptional medical care.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-8 h-8 bg-[#0891B2] rounded-full flex items-center justify-center hover:bg-[#06b6d4] transition-colors"
              >
                <Facebook className="w-4 h-4 text-white" />
                <span className="sr-only">Facebook</span>
              </a>
              <a
                href="#"
                className="w-8 h-8 bg-[#0891B2] rounded-full flex items-center justify-center hover:bg-[#06b6d4] transition-colors"
              >
                <Instagram className="w-4 h-4 text-white" />
                <span className="sr-only">Instagram</span>
              </a>
              <a
                href="#"
                className="w-8 h-8 bg-[#0891B2] rounded-full flex items-center justify-center hover:bg-[#06b6d4] transition-colors"
              >
                <Twitter className="w-4 h-4 text-white" />
                <span className="sr-only">Twitter</span>
              </a>
              <a
                href="#"
                className="w-8 h-8 bg-[#0891B2] rounded-full flex items-center justify-center hover:bg-[#06b6d4] transition-colors"
              >
                <Linkedin className="w-4 h-4 text-white" />
                <span className="sr-only">LinkedIn</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <span className="text-[#0891B2]">🔗</span> Quick Links
            </h4>
            <ul className="space-y-2">
              {["Privacy Policy", "Terms & Conditions", "FAQs", "Support Center"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-300 hover:text-white text-sm flex items-center">
                    <span className="mr-2">›</span> {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <span className="text-[#0891B2]">📞</span> Contact Info
            </h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 text-[#0891B2]" />
                <div>
                  <span className="text-gray-400 block text-xs">Email</span>
                  <span className="text-white">info@medscope.com</span>
                </div>
              </li>
              <li className="flex items-center gap-3 text-sm">
                <Phone className="w-4 h-4 text-[#0891B2]" />
                <div>
                  <span className="text-gray-400 block text-xs">Phone</span>
                  <span className="text-white">01003252891</span>
                </div>
              </li>
              <li className="flex items-center gap-3 text-sm">
                <AlertTriangle className="w-4 h-4 text-red-500" />
                <div>
                  <span className="text-gray-400 block text-xs">Emergency</span>
                  <span className="text-white">123</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-600 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            © 2025 MedScope. All rights reserved. Empowering Healthcare Excellence
          </p>
        </div>
      </div>
    </footer>
  )
}
