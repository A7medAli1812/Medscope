import { Users, Clock, Shield } from "lucide-react"

const features = [
  {
    icon: Users,
    title: "Expert Medical Care",
    description:
      "Connect with qualified healthcare professionals and access comprehensive medical services with personalized treatment plans.",
  },
  {
    icon: Clock,
    title: "24/7 Availability",
    description:
      "Round-the-clock access to emergency services and real-time bed availability information across our network.",
  },
  {
    icon: Shield,
    title: "Secure Platform",
    description:
      "HIPAA-compliant security ensuring your medical information remains private and protected with end-to-end encryption.",
  },
]

export default function FeaturesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 text-center">
        {/* Badge */}
        <span className="inline-block bg-[#0891B2] text-white text-sm px-4 py-1 rounded-full mb-4">
          why you choose midscope ?
        </span>

        <h2 className="text-[#164E63] text-3xl md:text-4xl font-bold mb-4">
          Modern Healthcare
          <br />
          Management
        </h2>

        <p className="text-gray-600 max-w-2xl mx-auto mb-12">
          Our comprehensive platform streamlines hospital operations and enhances patient care through innovative
          technology solutions
        </p>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center">
              <div className="w-16 h-16 bg-[#164E63] rounded-2xl flex items-center justify-center mb-4">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-[#164E63] font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
