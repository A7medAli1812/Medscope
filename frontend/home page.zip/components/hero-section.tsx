import Image from "next/image"

export default function HeroSection() {
  return (
    <section className="relative w-full">
      {/* Background Image - Full Width */}
      <div className="relative w-full h-[500px] md:h-[580px] lg:h-[620px]">
        <Image
          src="/images/hero.jpg"
          alt="Modern Hospital Building"
          fill
          className="object-cover object-center"
          priority
        />

        <div
          className="absolute inset-0 bg-gradient-to-r from-[#f0f4f7]/90 via-[#f0f4f7]/50 to-transparent"
          style={{ width: "45%" }}
        />

        <div className="absolute top-16 md:top-20 left-6 md:left-12 lg:left-16">
          <h1 className="text-[#164E63] text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">Your Health,</h1>
          <h2 className="text-[#0891B2] text-3xl md:text-4xl lg:text-5xl font-bold mt-2 ml-4 md:ml-6">Our Priority</h2>
        </div>
      </div>
    </section>
  )
}
