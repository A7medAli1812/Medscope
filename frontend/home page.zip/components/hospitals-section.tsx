import { MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"

const hospitals = [
  {
    name: "City General Hospital",
    location: "Downtown, New York",
    image: "/images/hospital-20partener1-y.jpg",
    rating: 4.5,
    tags: ["Emergency", "ICU"],
  },
  {
    name: "Metro Medical Center",
    location: "Midtown, New York",
    image: "/images/hospital-20partener2.jpg",
    rating: 4.8,
    tags: ["Cardiology", "Surgery"],
  },
]

export default function HospitalsSection() {
  return (
    <section className="py-16 bg-gradient-to-b from-white to-[#E0F2FE]">
      <div className="container mx-auto px-4 text-center">
        {/* Badge */}
        <span className="inline-block bg-[#164E63] text-white text-sm px-4 py-1 rounded-full mb-4">
          Trusted Network
        </span>

        <h2 className="text-[#0891B2] text-3xl md:text-4xl font-bold mb-4">Partner Hospitals</h2>

        <p className="text-gray-600 max-w-xl mx-auto mb-12">
          Trusted healthcare facilities in our network providing exceptional medical care
        </p>

        {/* Hospitals Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-8">
          {hospitals.map((hospital, index) => (
            <div key={index} className="relative rounded-2xl overflow-hidden shadow-lg group">
              <img
                src={hospital.image || "/placeholder.svg"}
                alt={hospital.name}
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />

              {/* Rating Badge */}
              <div className="absolute top-4 right-4 bg-[#0891B2] text-white text-sm px-2 py-1 rounded-full flex items-center gap-1">
                <span>★</span> {hospital.rating}
              </div>

              {/* Content */}
              <div className="absolute bottom-4 left-4 text-left">
                <h3 className="text-white font-bold text-xl mb-1">{hospital.name}</h3>
                <div className="flex items-center text-white/80 text-sm mb-2">
                  <MapPin className="w-4 h-4 mr-1" />
                  {hospital.location}
                </div>
                <div className="flex gap-2">
                  {hospital.tags.map((tag, i) => (
                    <span key={i} className="bg-[#0891B2] text-white text-xs px-2 py-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <Button className="bg-[#0891B2] hover:bg-[#0e7490] text-white px-8 py-6 rounded-full text-lg">
          View All Partner Hospitals →
        </Button>
      </div>
    </section>
  )
}
